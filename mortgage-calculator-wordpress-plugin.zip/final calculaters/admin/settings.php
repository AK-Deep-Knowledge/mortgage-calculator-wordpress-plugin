<h2>Settings</h2>
<p>Yahan aap plugin ki settings rakh sakte ho.</p>
